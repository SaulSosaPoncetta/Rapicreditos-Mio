import { IsNumber, IsOptional, IsString } from 'class-validator';

export class RegistrarPagoDto {
  @IsNumber()
  personaId: number;

  @IsNumber()
  creditoId: number;

  @IsNumber()
  monto: number;

  @IsString()
  @IsOptional()
  mensaje?: string;

  cuota: {
    id_cuota: number;
    numero: number;
  };
}
