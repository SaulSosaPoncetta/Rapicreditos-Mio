import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Credito } from '../../credito/entities/credito.entity';
import { Cuota } from '../../cuota/entities/cuota.entity';
import { Persona } from '../../persona/entities/persona.entity';

@Entity()
export class Pago {
  @PrimaryGeneratedColumn()
  id_pago: number;

  @Column('decimal', { precision: 12, scale: 2 })
  monto_cuota: number;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  fecha_pago: Date;

  @Column({ nullable: true })
  mensaje?: string;

  @ManyToOne(() => Cuota, { nullable: true })
  cuota?: Cuota;

  @ManyToOne(() => Persona)
  persona: Persona;

  @ManyToOne(() => Credito)
  credito: Credito;
}
